from flask import Flask, render_template, request
import pandas as pd
import pickle
import os

app = Flask(__name__)

MODEL_PATH = 'model/emergency_model.pkl'
model = None  # Global model variable

# Load the trained model at app startup
if os.path.exists(MODEL_PATH):
    with open(MODEL_PATH, 'rb') as file:
        model = pickle.load(file)
    print("Model loaded successfully.")
else:
    print("No trained model found. Please train the model first.")

@app.route('/')
@app.route('/')
def home():
    model_status = "Trained" if model else "Not Trained"
    return render_template('index.html', model_status=model_status)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        global model
        
        if model is None:
            return {'error': 'Model not trained yet. Please train the model first.'}, 400
        
        data = request.form
        
        hour = int(data['hour'])
        zipcode = int(data['zipcode'])
        day_of_week = data['day_of_week']
        keyword = data['keyword']
        city = data['city']
        
        if 6 <= hour < 12:
            time_of_day = 'Morning'
        elif 12 <= hour < 18:
            time_of_day = 'Afternoon'
        elif 18 <= hour < 22:
            time_of_day = 'Evening'
        else:
            time_of_day = 'Night'
            
        is_weekend = 1 if day_of_week in ['Saturday', 'Sunday'] else 0
        
        if keyword.lower() in ['crash', 'collision', 'accident', 'traffic']:
            keyword_type = 'Traffic'
        elif keyword.lower() in ['fire', 'smoke', 'burning', 'flames']:
            keyword_type = 'Fire'
        else:
            keyword_type = 'Medical'
            
        input_df = pd.DataFrame({
            'Hour': [hour],
            'Zipcode': [zipcode],
            'Day_of_Week': [day_of_week],
            'Keyword': [keyword],
            'City': [city],
            'Time_of_Day': [time_of_day],
            'Is_Weekend': [is_weekend],
            'Keyword_Type': [keyword_type]
        })
        
        prediction_encoded = model.predict(input_df)[0]
        prediction_proba = model.predict_proba(input_df)[0].tolist()
        
        emergency_types = ['Traffic', 'Fire', 'Medical']
        prediction = emergency_types[prediction_encoded]
        
        confidence_scores = {emergency_types[i]: round(prediction_proba[i] * 100, 2) for i in range(len(emergency_types))}
        
        return {
            'prediction': prediction,
            'confidence_scores': confidence_scores,
            'input_features': {
                'Hour': hour,
                'Zipcode': zipcode,
                'Day_of_Week': day_of_week,
                'Keyword': keyword,
                'City': city,
                'Time_of_Day': time_of_day,
                'Is_Weekend': 'Yes' if is_weekend else 'No',
                'Keyword_Type': keyword_type
            }
        }
    
    except Exception as e:
        return {'error': str(e)}, 500

@app.route('/train', methods=['POST'])
def train_model():
    try:
        from model.train_model import train_emergency_model
        
        accuracy = train_emergency_model()
        
        # After training, reload the new model
        global model
        if os.path.exists(MODEL_PATH):
            with open(MODEL_PATH, 'rb') as file:
                model = pickle.load(file)
            print("Model reloaded successfully after training.")
        
        return {'success': True, 'accuracy': accuracy}
    
    except Exception as e:
        return {'error': str(e)}, 500

if __name__ == '__main__':
    app.run(debug=True)
